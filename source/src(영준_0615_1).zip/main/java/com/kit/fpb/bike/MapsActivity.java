package com.kit.fpb.bike;

import android.*;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    protected LocationManager manager1;
    protected MyLocationListener locate;

    private GoogleApiClient client;
    private ArrayList<LatLng> arrayPoints;
    private ArrayList<LatLng> arrayPoints2;

    protected double curlati, curlong;
    protected double polilati ,polilong = 0;
    protected double curdistance;
    protected Location location1, location2;
    protected int a=0;
    protected String userid = "swan2202";
    protected String databaseName;
    protected SQLiteDatabase database;
    protected String tableName = "locateTable";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        manager1 = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locate = new MyLocationListener();
        arrayPoints = new ArrayList<LatLng>();
        arrayPoints2 = new ArrayList<LatLng>();
        location1 = new Location("point A");
        location2 = new Location("point B");

        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LatLng korea = new LatLng(36.16523, 127.5439476);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(korea, 8));
        mMap.setMyLocationEnabled(true);

        //mMap.addMarker(new MarkerOptions().position(new LatLng(35.4844695, 128.3155663)).title("함안창녕보"));*/
        search();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, "Maps Page",
                Uri.parse("http://host/path"),
                Uri.parse("android-app://com.example.jun.maptest/http/host/path")
        );
        //AppIndex.AppIndexApi.start(client, viewAction);
        moveCamera();
    }

    @Override
    public void onStop() {
        super.onStop();

        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, "Maps Page",
                Uri.parse("http://host/path"),
                Uri.parse("android-app://com.example.jun.maptest/http/host/path")
        );

        client.disconnect();
    }


    public void search() {
        databaseName = userid;
        try {
            database = openOrCreateDatabase(databaseName, Context.MODE_PRIVATE, null);
            Cursor cursor = database.rawQuery("SELECT lat, lon FROM " + tableName, null);

            startManagingCursor(cursor);

            //String[] columns = new String[]{"lat", "lon"};
            //int[] to = new int[]{};// 텍스트뷰 아이디

            //SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.customer_item, cusor, columns, to);

            Log.d("Database", "데이터 조회 : " + databaseName);
            int count = cursor.getCount();
            Log.d("Database", "결과 레코드의 갯수 : " + count);

            for (int i = 0; i < count; i++) {
                cursor.moveToNext();
                //int _id = cursor.getInt(0);
                String lat = cursor.getString(0);
                String lon = cursor.getString(1);

                polilati = Double.parseDouble(lat);
                polilong = Double.parseDouble(lon);

                arrayPoints.add(new LatLng(polilati,polilong));
                mMap.addPolyline(new PolylineOptions()
                        .color(Color.RED)
                        .width(6)
                        .addAll(arrayPoints));
                Log.d("Database", "레코드 # " + i + ":" + lat + "," + lon);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void moveCamera() {

        long minTime = 3000;
        float minDistance = 0;

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            return;
        }

        manager1.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                minTime, minDistance, locate);

        manager1.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                minTime, minDistance, locate);
    }

    class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {
            curlati = location.getLatitude(); //위도값 y
            curlong = location.getLongitude();

            if (a == 0) {
                location1.setLongitude(curlong);
                location1.setLatitude(curlati);
                a = a + 1;
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(curlati,curlong), 15));

                arrayPoints2.add(new LatLng(curlati,curlong));
                mMap.addPolyline(new PolylineOptions()
                        .color(Color.RED)
                        .width(6)
                        .addAll(arrayPoints2));
            } else {
                location2.setLongitude(curlong);
                location2.setLatitude(curlati);
                curdistance = location1.distanceTo(location2);

                if (curdistance < 3.5) {
                    Log.d("locate", " x ");
                } else if (curdistance > 40) {
                    Log.d("locate", " x");
                } else {
                    Log.d("locate", " o ");

                    location1.setLongitude(curlong);
                    location1.setLatitude(curlati);

                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(curlati,curlong), 15));

                    arrayPoints2.add(new LatLng(curlati,curlong));
                    mMap.addPolyline(new PolylineOptions()
                            .color(Color.RED)
                            .width(6)
                            .addAll(arrayPoints2));

                }

            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }
}
