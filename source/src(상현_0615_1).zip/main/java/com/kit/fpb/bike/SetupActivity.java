package com.kit.fpb.bike;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SetupActivity extends AppCompatActivity {
    public static final String COURSETAG = "CourseTag";

    protected JSONObject mResult = null;

    protected ArrayList<CourseInfo> mArray = new ArrayList<CourseInfo>();
    protected ListView mList;
    protected CourseAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;

    public static final String KEY_ID = "user_id";
    public static final String KEY_NAME = "name";
    public static final String user_id = "swan2202";
    public int KEY_POSITION;
    protected int select = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        mAdapter = new CourseAdapter(this, R.layout.course_setup);
        mList = (ListView) findViewById(R.id.course_user);
        mList.setAdapter(mAdapter);
        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                KEY_POSITION = position;

                AlertDialog.Builder alt_bld = new AlertDialog.Builder(SetupActivity.this);

                alt_bld.setMessage("선택하신 코스를 삭제하시겠습니까?").setCancelable(
                        false).setPositiveButton("삭제",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                CourseInfo info = mArray.get(KEY_POSITION);
                                String url = "http://128.199.238.222/course_delete.php";

                                final String user_id = "swan2202";
                                final String name = info.getName();

                                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) { }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Toast.makeText(SetupActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                                            }
                                        }){
                                    @Override
                                    protected Map<String,String> getParams(){
                                        Map<String,String> params = new HashMap<String, String>();
                                        params.put(KEY_ID, user_id);
                                        params.put(KEY_NAME, name);
                                        return params;
                                    }
                                };

                                RequestQueue requestQueue = Volley.newRequestQueue(SetupActivity.this);
                                requestQueue.add(stringRequest);

                                Intent intent = new Intent(getApplicationContext(), SetupActivity.class);
                                finish();
                                startActivity(intent);
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = alt_bld.create();
                // Title for AlertDialog
                alert.setTitle("Weather Rider");
                // Icon for AlertDialog
                alert.setIcon(R.drawable.app);
                alert.show();
            }
        });

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();
    }

    public void refresh() {
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_add) {
            final String items[] = { "개별 추가", "추천 코스" };

            AlertDialog.Builder ab = new AlertDialog.Builder(SetupActivity.this);
            ab.setTitle("Weather Rider");
            ab.setSingleChoiceItems(items, 0,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            switch (whichButton) {
                                case 0:
                                    select = 0;
                                    break;
                                case 1:
                                    select = 1;
                                    break;
                            }
                        }
                    }).setPositiveButton("확인",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            switch (select) {
                                case -1:
                                case 0:
                                    Intent intent_0 = new Intent(getApplicationContext(), CourseActivity.class);
                                    finish();
                                    startActivity(intent_0);
                                    break;
                                case 1:
                                    Intent intent_1 = new Intent(getApplicationContext(), RecommendActivity.class);
                                    finish();
                                    startActivity(intent_1);
                                    break;
                            }
                            select = 0;
                        }
                    }).setNegativeButton("취소",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) { }
                    });
            ab.setIcon(R.drawable.app);
            ab.show();

            return true;
        } else if (id == R.id.action_ok) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    protected void requestCourse()
    {
        String url ="http://128.199.238.222/course_user.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SetupActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );

        jsObjRequest.setTag(COURSETAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                if (jsonChildNode.getString("id").equals(user_id)) {
                    String name = jsonChildNode.getString("name");
                    String address = jsonChildNode.getString("address");
                    mArray.add(new CourseInfo(name, address));
                }
            }
        }catch(JSONException | NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error : "+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }
        mAdapter.notifyDataSetChanged();
    }

    public class CourseInfo {
        String name;
        String address;

        public CourseInfo(String name, String address) {
            this.name = name;
            this.address = address;
        }

        public String getName() { return name; }

        public String getAddress() { return address; }
    }

    static class CourseViewHolder {
        TextView txName;
        TextView txAddress;
    }

    public class CourseAdapter extends ArrayAdapter<CourseInfo> {
        private LayoutInflater mInflater = null;
        public CourseAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.course_setup, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txName = (TextView) v.findViewById(R.id.name);
                viewHolder.txAddress = (TextView) v.findViewById(R.id.address);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            CourseInfo info = mArray.get(position);
            if(info != null) {
                viewHolder.txName.setText(info.getName());
                viewHolder.txAddress.setText(info.getAddress());
            }
            return  v;
        }
    }
}