package com.kit.fpb.bike;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RecommendActivity extends AppCompatActivity {
    public static final String COURSETAG = "CourseTag";

    protected JSONObject mResult = null;

    protected ArrayList<CourseInfo> mArray = new ArrayList<CourseInfo>();
    protected ListView mList;
    protected CourseAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend);

        mAdapter = new CourseAdapter(this, R.layout.course_recommend);
        mList = (ListView) findViewById(R.id.recommendView);
        mList.setAdapter(mAdapter);
        mList.setFocusable(false);
        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CourseInfo info = mArray.get(position);
                String [] rec = null;

                switch (info.getName()) {
                    case "아라 자전거길":
                        rec = new String[]{"아라서해갑문", "아라한강갑문"};
                        break;
                    case "한강종주 자전거길":
                        rec = new String[]{"아라한강갑문", "뚝섬 전망대"};
                        break;
                    case "남한강 자전거길":
                        rec = new String[]{"능내역", "양평군립미술관", "이포보", "여주보", "강천보", "충주 탄금대"};
                        break;
                    case "북한강 자전거길":
                        rec = new String[]{"밝은 광장", "샛터삼거리", "경강교", "신매대교"};
                        break;
                    case "새재 자전거길":
                        rec = new String[]{"충주 탄금대", "수안보온천", "이화령 휴게소", "문경 불정역", "상주 상풍교"};
                        break;
                    case "낙동강 자전거길":
                        rec = new String[]{"상주 상풍교", "상주보", "낙단보", "구미보", "칠곡보", "강정고령보", "달성보",
                                "합천창녕보", "창녕함안보", "양산 물문화관", "낙동강 하구둑"};
                        break;
                    case "금강 자전거길":
                        rec = new String[]{"대청댐", "세종보", "공주보", "백제보", "익산 성당포구", "금강 하구둑"};
                        break;
                    case "영산강 자전거길":
                        rec = new String[]{"담양댐", "메타세쿼이아길", "담양 대나무숲", "승촌보", "죽산보", "느러지 전망대", "영산강 하구둑"};
                        break;
                    case "섬진강 자전거길":
                        rec = new String[]{"장군목", "향가유원지", "횡탄정", "사성암", "남도대교", "매화마을", "배알도수변공원"};
                        break;
                }

                Intent intent = new Intent(getApplicationContext(), RecommendInsertActivity.class);
                intent.putExtra("rec", rec);
                intent.putExtra("name", info.getName());
                finish();
                startActivity(intent);
            }
        });

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();
    }

    protected void requestCourse()
    {
        String url ="http://128.199.238.222/course_recommend.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RecommendActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );
        jsObjRequest.setTag(COURSETAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                String name=jsonChildNode.getString("name");
                String content=jsonChildNode.getString("content");
                String distance=jsonChildNode.getString("distance");
                String time=jsonChildNode.getString("time");
                mArray.add(new CourseInfo(name, content, distance, time));
            }
        }catch(JSONException | NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error"+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }
        mAdapter.notifyDataSetChanged();
    }

    public class CourseInfo {
        String name;
        String content;
        String distance;
        String time;

        public CourseInfo(String name, String content, String distance, String time) {
            this.name = name;
            this.content = content;
            this.distance = distance;
            this.time = time;
        }

        public String getName() { return name; }

        public String getContent() { return content; }

        public String getDistance() { return distance; }

        public String getTime() { return time; }
    }

    static class CourseViewHolder {
        TextView txName;
        TextView txContent;
        TextView txDistance;
    }

    public class CourseAdapter extends ArrayAdapter<CourseInfo> {
        private LayoutInflater mInflater = null;
        public CourseAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.course_recommend, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txName = (TextView) v.findViewById(R.id.name);
                viewHolder.txContent = (TextView) v.findViewById(R.id.content);
                viewHolder.txDistance = (TextView) v.findViewById(R.id.distance);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            CourseInfo info = mArray.get(position);
            if(info != null) {
                viewHolder.txName.setText(info.getName());
                viewHolder.txContent.setText(info.getContent());
                viewHolder.txDistance.setText("총 이동거리 : " + info.getDistance() + " / 예상 소요시간 : " + info.getTime());
            }
            return  v;
        }
    }
}