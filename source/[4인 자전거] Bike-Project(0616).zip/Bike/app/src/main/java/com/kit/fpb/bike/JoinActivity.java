package com.kit.fpb.bike;

/**
 * Created by Dolm on 2016-06-14.
 */
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class JoinActivity extends Activity {

    String check;
    String url = "http://128.199.238.222/join.php";
    String url1= "http://128.199.238.222/check.php";
    String id;
    String password;
    EditText editText_id;
    EditText editText_password;

    ProgressDialog PD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        PD = new ProgressDialog(this);
        PD.setMessage("Loading.....");
        PD.setCancelable(false);

        editText_id= (EditText) findViewById(R.id.item_et_id);
        editText_password=(EditText)findViewById(R.id.item_et_password);

    }
    public void checkid(View v){
        id = editText_id.getText().toString();
        StringRequest request = new StringRequest(Request.Method.POST,url1,
                new Response.Listener<String>() {
                    public void onResponse(String response)
                    {
                        if(response.trim().equals("success")){
                            Toast.makeText(JoinActivity.this, "이미 사용중인 아이디 입니다.", Toast.LENGTH_LONG).show();

                        }else {
                            Toast.makeText(getApplicationContext(),"사용 가능한 아이디 입니다.",Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),
                        "Error", Toast.LENGTH_SHORT).show();
            }
        })
        {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                return params;
            }
        };
        // Adding request to request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        request.setShouldCache(false);
        requestQueue.add(request);
    }
    public void insert(View v) {
        PD.show();
        id = editText_id.getText().toString();
        password = editText_password.getText().toString();

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    public void onResponse(String response) {
                        PD.dismiss();
                        editText_id.setText("");
                        editText_password.setText("");
                        Toast.makeText(getApplicationContext(),
                                "회원가입 완료",
                                Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(JoinActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                }, new Response.ErrorListener() {

            public void onErrorResponse(VolleyError error) {
                PD.dismiss();
                Toast.makeText(getApplicationContext(),
                        "failed to insert", Toast.LENGTH_SHORT).show();
            }
        }) {

            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("item_id", id);
                params.put("item_password",password);
                return params;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
       request.setShouldCache(false);
        requestQueue.add(request);
    }
}

