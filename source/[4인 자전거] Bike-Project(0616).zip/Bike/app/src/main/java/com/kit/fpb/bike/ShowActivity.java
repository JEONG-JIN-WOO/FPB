package com.kit.fpb.bike;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.okhttp.OkHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ShowActivity extends AppCompatActivity {
    public static final String COURSETAG = "CourseTag";
    public static final String KEY_ID = "user_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_DISTANCE = "distance";
    public int KEY_POSITION;

    protected TextView mSpeed, mDis;
    private LocationManager lm;
    private LocationListener ll;
    double mySpeed, maxSpeed;

    protected JSONObject mResult = null;
    protected ArrayList<CourseInfo> mArray = new ArrayList<CourseInfo>();
    protected ArrayList<ShortWeather> shortWeathers = new ArrayList<ShortWeather>();
    protected ListView mList;
    protected CourseAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected String sRegion = null;
    protected int select = -1;

    protected String databaseName;
    protected SQLiteDatabase database;
    protected String tableName = "locateTable";

    protected LocationManager manager;
    protected MyLocationListener listener;

    protected double curlati, curlong, curdistance;
    protected double prelati = 0, prelong = 0, distance = 0;
    protected Location location1, location2, location3, location4;
    protected int a = 0;
    protected int num = 1;
    protected int startingCount = 0;
    protected double maxdistance = 0;
    protected int check_distance = 0;
    protected double[] rest_distance;
    protected int temp_distance = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        mSpeed = (TextView) findViewById(R.id.speed);
        maxSpeed = mySpeed = 0;
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        ll = new SpeedoActionListener();
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, ll);
        } catch (SecurityException e) {
            Toast.makeText(ShowActivity.this, "SecurityException : Error", Toast.LENGTH_SHORT).show();
        }

        mDis = (TextView) findViewById(R.id.dis);

        new ReceiveShortWeather().execute();

        mAdapter = new CourseAdapter(this, R.layout.course_item);
        mList = (ListView) findViewById(R.id.listView);
        mList.setAdapter(mAdapter);
        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CourseInfo info = mArray.get(position);
                KEY_POSITION = position;

                final String sRegion = info.getsRegion();
                final String lRegion = info.getlRegion();
                final String items[] = {"단기예보  ▶  향후 2일", "중기예보  ▶  향후 10일", "삭제"};

                AlertDialog.Builder ab = new AlertDialog.Builder(ShowActivity.this);
                ab.setTitle("Weather Rider");
                ab.setSingleChoiceItems(items, 0,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                switch (whichButton) {
                                    case 0:
                                        select = 0;
                                        break;
                                    case 1:
                                        select = 1;
                                        break;
                                    case 2:
                                        select = 2;
                                        break;
                                }
                            }
                        }).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                switch (select) {
                                    case -1:
                                    case 0:
                                        Intent intent_0 = new Intent(getApplicationContext(), ShortWeatherActivity.class);
                                        intent_0.putExtra("sRegion", sRegion);
                                        startActivity(intent_0);
                                        break;
                                    case 1:
                                        Intent intent_1 = new Intent(getApplicationContext(), LongWeatherActivity.class);
                                        intent_1.putExtra("lRegion", lRegion);
                                        startActivity(intent_1);
                                        break;
                                    case 2:
                                        CourseInfo info = mArray.get(KEY_POSITION);
                                        String url = "http://128.199.238.222/course_delete.php";

                                        final String user_id = MainActivity.user_id;
                                        final String name = info.getName();

                                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                                                new Response.Listener<String>() {
                                                    @Override
                                                    public void onResponse(String response) {
                                                    }
                                                },
                                                new Response.ErrorListener() {
                                                    @Override
                                                    public void onErrorResponse(VolleyError error) {
                                                        Toast.makeText(ShowActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                                                    }
                                                }) {
                                            @Override
                                            protected Map<String, String> getParams() {
                                                Map<String, String> params = new HashMap<String, String>();
                                                params.put(KEY_ID, user_id);
                                                params.put(KEY_NAME, name);
                                                return params;
                                            }
                                        };

                                        RequestQueue requestQueue = Volley.newRequestQueue(ShowActivity.this);
                                        requestQueue.add(stringRequest);

                                        Intent intent = new Intent(getApplicationContext(), ShowActivity.class);
                                        finish();
                                        startActivity(intent);
                                        break;
                                }
                                select = 0;
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                            }
                        });
                ab.setIcon(R.drawable.app);
                ab.show();
            }
        });

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();

        manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        listener = new MyLocationListener();
        location1 = new Location("point A");
        location2 = new Location("point B");
        location3 = new Location("point C");
        location4 = new Location("point D");
        createDb();
        createTable();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_show, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_map) {

            Intent intent = new Intent(getApplicationContext(), MapActivity.class);
            String[] course_name = new String[mArray.size()];
            String[] course_lat = new String[mArray.size()];
            String[] course_lng = new String[mArray.size()];

            for (int i = 0; i < mArray.size(); i++) {
                course_name[i] = mArray.get(i).getName();
                course_lat[i] = mArray.get(i).getLat();
                course_lng[i] = mArray.get(i).getLng();
            }

            intent.putExtra("name", course_name);
            intent.putExtra("lat", course_lat);
            intent.putExtra("lng", course_lng);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_start) {
            Toast.makeText(ShowActivity.this, "주행 시작", Toast.LENGTH_LONG).show();
            startingCount = startingCount + 1;

            onResume();
            return true;
        } else if (id == R.id.action_pause) {
            Toast.makeText(ShowActivity.this, "주행 종료", Toast.LENGTH_LONG).show();
            search();
            database.execSQL("delete from " + tableName);
            distance = 0;
            startingCount = 0;

            onPause();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public class ShortWeather {
        private String hour;  // 시간
        private String day;
        private String temp;  // 온도
        private String wfKor; // 상태
        private String pop; // 강수확률
        private String reh; // 습도
        private String tmx;
        private String tmn;
        private Uri uri;

        public ShortWeather(String day, String temp, String wfKor, Uri uri) {
            this.day = day;
            this.temp = temp;
            this.wfKor = wfKor;
            this.uri = uri;
        }

        public ShortWeather() {
        }

        public String getTmx() {
            return tmx;
        }

        public void setTmx(String tmx) {
            this.tmx = tmx;
        }

        public String getTmn() {
            return tmn;
        }

        public void setTmn(String tmn) {
            this.tmn = tmn;
        }

        public String getDay() {
            return day;
        }

        public void setDay(String day) {
            this.day = day;
        }

        public String getReh() {
            return reh;
        }

        public void setReh(String reh) {
            this.reh = reh;
        }

        public String getPop() {
            return pop;
        }

        public void setPop(String pop) {
            this.pop = pop;
        }

        public void setHour(String hour) {
            this.hour = hour;
        }

        public void setTemp(String temp) {
            this.temp = temp;
        }

        public void setWfKor(String wfKor) {
            this.wfKor = wfKor;
        }

        public String getHour() {
            return hour;
        }

        public String getTemp() {
            return temp;
        }

        public String getWfKor() {
            return wfKor;
        }

        public Uri getUri() {
            return uri;
        }
    }

    public class ReceiveShortWeather extends AsyncTask<URL, Integer, Long> {

        protected Long doInBackground(URL... urls) {

            String url = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=" + sRegion;

            OkHttpClient client = new OkHttpClient();

            com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder().url(url).build();

            com.squareup.okhttp.Response response = null;

            try {
                response = client.newCall(request).execute();
                parseXML(response.body().string());
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onPostExecute(Long result) {
            // for(int i=0; i<shortWeathers.size(); i++) { }

            mAdapter.notifyDataSetChanged();
        }

        void parseXML(String xml) {
            try {
                String tagName = "";
                boolean onHour = false;
                boolean onDay = false;
                boolean onTem = false;
                boolean onWfKor = false;
                boolean onPop = false;
                boolean onEnd = false;
                boolean isItemTag1 = false;
                int i = 0;

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                XmlPullParser parser = factory.newPullParser();

                parser.setInput(new StringReader(xml));

                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        tagName = parser.getName();
                        if (tagName.equals("data")) {
                            shortWeathers.add(new ShortWeather());
                            onEnd = false;
                            isItemTag1 = true;
                        }
                    } else if (eventType == XmlPullParser.TEXT && isItemTag1) {
                        if (tagName.equals("hour") && !onHour) {
                            shortWeathers.get(i).setHour(parser.getText());
                            onHour = true;
                        }
                        if (tagName.equals("day") && !onDay) {
                            shortWeathers.get(i).setDay(parser.getText());
                            onDay = true;
                        }
                        if (tagName.equals("temp") && !onTem) {
                            shortWeathers.get(i).setTemp(parser.getText());
                            onTem = true;
                        }
                        if (tagName.equals("wfKor") && !onWfKor) {
                            shortWeathers.get(i).setWfKor(parser.getText());
                            onWfKor = true;
                        }
                        if (tagName.equals("pop") && !onPop) {
                            shortWeathers.get(i).setPop(parser.getText());
                            onPop = true;
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        if (tagName.equals("s06") && onEnd == false) {
                            i++;
                            onHour = false;
                            onDay = false;
                            onTem = false;
                            onWfKor = false;
                            onPop = false;
                            isItemTag1 = false;
                            onEnd = true;
                        }
                    }

                    eventType = parser.next();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private class SpeedoActionListener implements LocationListener {
        @Override
        public void onLocationChanged(Location location) {
            if (location != null) {
                mySpeed = location.getSpeed();
                if (mySpeed > maxSpeed) {
                    maxSpeed = mySpeed;
                }
                mSpeed.setText("현재속도 : " + mySpeed + " km/h");
            }
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    }

    protected void requestCourse() {
        String url = "http://128.199.238.222/selectjson.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        
                    }
                }
        );
        jsObjRequest.setTag(COURSETAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList() {
        mArray.clear();
        try {
            JSONArray jsonMainNode = mResult.getJSONArray("list");
            int create_check = 0;

            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);

                if (jsonChildNode.getString("id").equals(MainActivity.user_id)) {
                    String name = jsonChildNode.getString("name");
                    String lat = jsonChildNode.getString("lat");
                    String lng = jsonChildNode.getString("lng");
                    String sReg = jsonChildNode.getString("sRegion");
                    String lRegion = jsonChildNode.getString("lRegion");
                    String rest = "";

                    sRegion = sReg;
                    create_check = 1;

                    mArray.add(new CourseInfo(name, lat, lng, sReg, lRegion, shortWeathers.get(i).getTemp(), shortWeathers.get(i).getWfKor(), rest));
                }
            }
            if (create_check == 0) {
                Toast.makeText(getApplicationContext(), "등록된 코스가 없어\n코스추가 화면으로 이동합니다.", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), SetupActivity.class);
                finish();
                startActivity(intent);
            }
            rest_distance = new double[mArray.size()];
        } catch (JSONException | NullPointerException e) {
            Toast.makeText(getApplicationContext(), "Error" + e.toString(), Toast.LENGTH_LONG).show();
            mResult = null;
        }
        mAdapter.notifyDataSetChanged();
    }

    public class CourseInfo {
        String name;
        String lat;
        String lng;
        String sRegion;
        String lRegion;
        String temp;
        String wfKor;
        String rest;

        public CourseInfo() {
        }

        public CourseInfo(String name, String lat, String lng, String sRegion, String lRegion, String temp, String wfKor, String rest) {
            this.name = name;
            this.lat = lat;
            this.lng = lng;
            this.sRegion = sRegion;
            this.lRegion = lRegion;
            this.temp = temp;
            this.wfKor = wfKor;
            this.rest = rest;
        }

        public String getName() {
            return name;
        }

        public String getLat() {
            return lat;
        }

        public String getLng() {
            return lng;
        }

        public String getsRegion() {
            return sRegion;
        }

        public String getlRegion() {
            return lRegion;
        }

        public String getTemp() {
            return temp;
        }

        public String getWfKor() {
            return wfKor;
        }

        public String getRest() {
            return rest;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setRest(String rest) {
            this.rest = rest;
        }
    }

    static class CourseViewHolder {
        TextView txName;
        TextView txRest;
        TextView txTemp;
        TextView txWfKor;
    }

    public class CourseAdapter extends ArrayAdapter<CourseInfo> {
        private LayoutInflater mInflater = null;

        public CourseAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if (v == null) {
                v = mInflater.inflate(R.layout.course_item, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txName = (TextView) v.findViewById(R.id.name);
                viewHolder.txRest = (TextView) v.findViewById(R.id.rest);
                viewHolder.txTemp = (TextView) v.findViewById(R.id.show_temp);
                viewHolder.txWfKor = (TextView) v.findViewById(R.id.show_wfkor);

                v.setTag(viewHolder);
            } else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            CourseInfo info = mArray.get(position);
            if (info != null) {
                viewHolder.txName.setText(info.getName());
                viewHolder.txRest.setText("남은거리 : " + info.rest + " km");
                viewHolder.txTemp.setText("현재온도 : " + info.getTemp() + " ℃");
                viewHolder.txWfKor.setText("날씨상태 : " + info.getWfKor());
            }
            return v;
        }
    }

    public void createDb() {
        databaseName = MainActivity.user_id;

        try {
            database = openOrCreateDatabase(databaseName, Context.MODE_PRIVATE, null);
            Log.d("Database", "데이터 베이스 생성 : " + databaseName);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createTable() {
        try {
            if (database != null) {
                database.execSQL("CREATE TABLE if not exists " + tableName + "(" + "_id integer PRIMARY KEY autoincrement, "
                        + "lat text, "
                        + "lon text, "
                        + "allDistance text"
                        + ")");

                Log.d("Database", "테이블 생성 : " + tableName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insert() {
        try {
            if (database != null) {
                database.execSQL("INSERT INTO " + tableName + "(lat, lon, allDistance ) VALUES "
                        + "('" + curlati + "','" + curlong + "','" + distance + "')");

                Log.d("Database", "데이터 추가 완료 : " + databaseName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void search() {
        try {
            if (database != null) {
                Cursor cursor = database.rawQuery("SELECT lat, lon, allDistance FROM " + tableName, null);

                startManagingCursor(cursor);

                String[] columns = new String[]{"lat", "lon", "allDistance"};

                Log.d("Database", "데이터 조회 : " + databaseName);
                int count = cursor.getCount();
                Log.d("Database", "결과 레코드의 갯수 : " + count);

                for (int i = 0; i < count; i++) {
                    cursor.moveToNext();
                    String lat = cursor.getString(0);
                    String lon = cursor.getString(1);
                    String allDistance = cursor.getString(2);

                    maxdistance = Double.parseDouble(allDistance);
                    Log.d("Database", "레코드 # " + i + ":" + lat + "," + lon + "," + allDistance);
                }
                Log.d("Database", "총이동거리 저장 :  " + maxdistance);

                String url = "http://128.199.238.222/distance_update.php";

                int temp_dis = 0;
                if (maxdistance > 0) {
                    String temp = "" + maxdistance;
                    int index = temp.indexOf(".");
                    temp = temp.substring(0, index);

                    if (check_distance == 0) {
                        temp_dis = Integer.parseInt(MainActivity.distance) + Integer.parseInt(temp);
                        temp_distance = temp_dis;
                        check_distance = 1;
                    } else {
                        temp_dis = temp_distance + Integer.parseInt(temp);
                    }
                } else {
                    if (check_distance == 0) {
                        temp_dis = Integer.parseInt(MainActivity.distance);
                        check_distance++;
                    } else {
                        temp_dis = temp_distance;
                    }
                }

                final String user_id = MainActivity.user_id;
                final String distance = "" + temp_dis;

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(ShowActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put(KEY_ID, user_id);
                        params.put(KEY_DISTANCE, distance);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(ShowActivity.this);
                requestQueue.add(stringRequest);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void mylocation() {

        long minTime = 3000;
        float minDistance = 0;


        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                minTime, minDistance, listener);

        manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                minTime, minDistance, listener);

    }

    class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {
            curlati = location.getLatitude(); //위도값 y
            curlong = location.getLongitude();

            Log.d("Database", "내 위치 : " + curlati + ", " + curlong);

            distanceCalcul();

            if (a == 0) {
                prelati = curlati;
                prelong = curlong;
                location1.setLongitude(curlong);
                location1.setLatitude(curlati);
                a = a + 1;

                insert();

            } else {
                location2.setLongitude(curlong);
                location2.setLatitude(curlati);
                curdistance = location1.distanceTo(location2);
                Log.d("Database", num + "번째 최근이동거리 : " + curdistance);
                if (curdistance < 3.5) {
                    Log.d("Database", "제자리 포함 x ");
                } else if (curdistance > 40) {
                    Log.d("Database", "잘못된 gps 포함 x");
                } else {

                    distance = distance + curdistance;
                    num = num + 1;
                    Toast.makeText(ShowActivity.this, "방금이동한거:" + curdistance + "총이동거리:" + distance, Toast.LENGTH_SHORT);
                    Log.d("Database", "총 이동거리 : " + distance);

                    if (distance > 0) {
                        String temp = "" + distance;
                        int index = temp.indexOf(".");
                        temp = temp.substring(0, index);

                        if (distance > 1000) {
                            index = Integer.parseInt(temp);
                            temp = (index / 1000) + "." + (index % 1000);
                            mDis.setText("이동거리 : " + temp + " km");
                        } else {
                            mDis.setText("이동거리 : " + temp + " m");
                        }
                    }

                    location1.setLongitude(curlong);
                    location1.setLatitude(curlati);

                    insert();
                }
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (startingCount == 1) {
            mylocation();
        }
    }

    @Override
    protected void onPause() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        manager.removeUpdates(listener);
        super.onPause();
    }

    protected void distanceCalcul()
    {
        for(int i =0; i<mArray.size(); i++)
        {
            if(i==0) {
                location3.setLatitude(curlati); location3.setLongitude(curlong);
                //location3.setLatitude(36.1379818); location3.setLongitude(128.3968911);
                Log.d("Database", "위치!!  : " + location3.getLatitude()+","+location3.getLongitude());
                location4.setLatitude(Double.parseDouble(mArray.get(i).getLat()));
                location4.setLongitude(Double.parseDouble(mArray.get(i).getLng()));
                rest_distance[i] = location3.distanceTo(location4);
                Log.d("Database", "현재 위치와 첫 마커 까지 거리  : " + rest_distance[i]);
                location3.setLatitude(Double.parseDouble(mArray.get(i).getLat()));
                location3.setLongitude(Double.parseDouble(mArray.get(i).getLng()));

                String temp = "" + rest_distance[i];
                int index = temp.indexOf(".");

                temp = temp.substring(0 ,index);
                index = Integer.parseInt(temp);
                temp = (index/1000) + "." + (index%1000);

                mArray.get(i).setRest(temp);
                mAdapter.notifyDataSetChanged();
            }
            else {
                location4.setLatitude(Double.parseDouble(mArray.get(i).getLat()));
                location4.setLongitude(Double.parseDouble(mArray.get(i).getLng()));
                rest_distance[i] = location3.distanceTo(location4);
                rest_distance[i] =rest_distance[i-1] + rest_distance[i];
                Log.d("Database", "그 다음 마커까지 거리 : #"+i+ "  " + rest_distance[i]);
                location3.setLatitude(Double.parseDouble(mArray.get(i).getLat()));
                location3.setLongitude(Double.parseDouble(mArray.get(i).getLng()));

                String temp = "" + rest_distance[i];
                int index = temp.indexOf(".");

                temp = temp.substring(0 ,index);
                index = Integer.parseInt(temp);
                temp = (index/1000) + "." + (index%1000);

                mArray.get(i).setRest(temp);
                mAdapter.notifyDataSetChanged();
            }
        }
    }
}