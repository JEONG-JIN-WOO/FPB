package com.kit.fpb.bike;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RecordActivity extends AppCompatActivity {
    public static final String RECORDTAG = "RecordTag";

    protected JSONObject mResult = null;

    protected ArrayList<RecordInfo> mArray = new ArrayList<RecordInfo>();
    protected ListView mList;
    protected RecordAdapter mAdapter;
    protected RequestQueue mQueue = null;

    protected RecordInfo [] rec_info = null;
    protected TextView mRecord = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        mRecord = (TextView) findViewById(R.id.myRecord);

        mAdapter = new RecordAdapter(this, R.layout.record_item);
        mList = (ListView) findViewById(R.id.recordView);
        mList.setAdapter(mAdapter);
        mList.setFocusable(false);

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();
    }

    protected void requestCourse()
    {
        String url ="http://128.199.238.222/record.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RecordActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );
        jsObjRequest.setTag(RECORDTAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");
            rec_info = new RecordInfo[jsonMainNode.length()];

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                String id=jsonChildNode.getString("id");
                int distance=jsonChildNode.getInt("distance");

                mArray.add(new RecordInfo(id, distance));
            }
        }catch(JSONException | NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error"+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }

        Collections.sort(mArray, new Comparator<RecordInfo>(){
            public int compare(RecordInfo obj1, RecordInfo obj2)
            {
                return (obj1.getDistance() > obj2.getDistance()) ? -1: (obj1.getDistance() < obj2.getDistance()) ? 1:0 ;
            }
        });
        mAdapter.notifyDataSetChanged();
    }

    public class RecordInfo {
        String id;
        int distance;

        public RecordInfo() { }

        public RecordInfo(String id, int distance) {
            this.id = id;
            this.distance = distance;
        }

        public String getId() { return id; }

        public int getDistance() { return distance; }

        public void setId(String id) { this.id = id; }

        public void setDistance(int distance) { this.distance = distance; }
    }

    static class CourseViewHolder {
        TextView txId;
        TextView txDistance;
    }

    public class RecordAdapter extends ArrayAdapter<RecordInfo> {
        private LayoutInflater mInflater = null;
        public RecordAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.record_item, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txId = (TextView) v.findViewById(R.id.record_id);
                viewHolder.txDistance = (TextView) v.findViewById(R.id.record_distance);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            RecordInfo info = mArray.get(position);
            if(info != null) {
                viewHolder.txId.setText((position+1) + "위  ▶  ID : " + info.getId());
                viewHolder.txDistance.setText("총 주행거리 : " + info.getDistance() + " M");
                if (info.getId().equals(MainActivity.user_id)) {
                    mRecord.setText("나의 순위 : " + (position+1) + "위  /  주행거리 : " + info.getDistance() + " M");
                }
            }
            return  v;
        }
    }
}