package com.kit.fpb.bike;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class CopyrightActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_copyright);
    }
}

