package com.kit.fpb.bike;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CourseActivity extends AppCompatActivity {
    public static final String COURSETAG = "CourseTag";

    protected JSONObject mResult = null;

    protected ArrayList<CourseInfo> mArray = new ArrayList<CourseInfo>();
    protected ListView mList;
    protected CourseAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;

    public static final String KEY_ID = "user_id";
    public static final String KEY_COURSE = "course";
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_LAT = "lat";
    public static final String KEY_LNG = "lng";
    public static final String KEY_SREGION = "sRegion";
    public static final String KEY_LREGION = "lRegion";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);

        mAdapter = new CourseAdapter(this, R.layout.course_setup);
        mList = (ListView) findViewById(R.id.courseView);
        mList.setAdapter(mAdapter);
        mList.setFocusable(false);
        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CourseInfo info = mArray.get(position);
                String url = "http://128.199.238.222/course_add.php";

                final String user_id = MainActivity.user_id;
                final String course = info.getName();
                final String address = info.getAddress();
                final String lat = info.getLat();
                final String lng = info.getLng();
                final String sRegion = info.getsRegion();
                final String lRegion = info.getlRegion();

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) { }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(CourseActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                            }
                        }){
                    @Override
                    protected Map<String,String> getParams(){
                        Map<String,String> params = new HashMap<String, String>();
                        params.put(KEY_ID, user_id);
                        params.put(KEY_COURSE, course);
                        params.put(KEY_ADDRESS, address);
                        params.put(KEY_LAT, lat);
                        params.put(KEY_LNG, lng);
                        params.put(KEY_SREGION, sRegion);
                        params.put(KEY_LREGION, lRegion);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(CourseActivity.this);
                requestQueue.add(stringRequest);

                Intent intent = new Intent(getApplicationContext(), SetupActivity.class);
                finish();
                startActivity(intent);
            }
        });


        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();
    }

    protected void requestCourse()
    {
        String url ="http://128.199.238.222/course_select.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CourseActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );
        jsObjRequest.setTag(COURSETAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                String name=jsonChildNode.getString("name");
                String address=jsonChildNode.getString("address");
                String lat=jsonChildNode.getString("lat");
                String lng=jsonChildNode.getString("lng");
                String sRegion=jsonChildNode.getString("sRegion");
                String lRegion=jsonChildNode.getString("lRegion");

                mArray.add(new CourseInfo(name, address, lat, lng, sRegion, lRegion));
            }
        }catch(JSONException | NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error"+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }
        mAdapter.notifyDataSetChanged();
    }

    public class CourseInfo {
        String name;
        String address;
        String lat;
        String lng;
        String sRegion;
        String lRegion;

        public CourseInfo(String name, String address, String lat, String lng, String sRegion, String lRegion) {
            this.name = name;
            this.address = address;
            this.lat = lat;
            this.lng = lng;
            this.sRegion = sRegion;
            this.lRegion = lRegion;
        }

        public String getName() { return name; }

        public String getAddress() { return address; }

        public String getLat() { return lat; }

        public String getLng() { return lng; }

        public String getsRegion() { return sRegion; }

        public String getlRegion() { return lRegion; }
    }

    static class CourseViewHolder {
        TextView txName;
        TextView txAddress;
    }

    public class CourseAdapter extends ArrayAdapter<CourseInfo> {
        private LayoutInflater mInflater = null;
        public CourseAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.course_setup, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txName = (TextView) v.findViewById(R.id.name);
                viewHolder.txAddress = (TextView) v.findViewById(R.id.address);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            CourseInfo info = mArray.get(position);
            if(info != null) {
                viewHolder.txName.setText(info.getName());
                viewHolder.txAddress.setText(info.getAddress());
            }
            return  v;
        }
    }
}