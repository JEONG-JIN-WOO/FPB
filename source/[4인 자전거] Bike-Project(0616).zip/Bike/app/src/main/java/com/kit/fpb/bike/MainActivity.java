package com.kit.fpb.bike;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String USERTAG = "UserTag";
    public static String user_id = "", distance = "";
    public static int USER_POSITION = 0;;

    protected JSONObject mResult = null;

    protected ArrayList<UserInfo> mArray = new ArrayList<UserInfo>();
    protected RequestQueue mQueue = null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

        Intent intent = getIntent();
        user_id = LoginActivity.user_id;

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestUser();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_info) {
            Intent intent = new Intent(MainActivity.this, CopyrightActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    protected void requestUser()
    {
        String url ="http://128.199.238.222/search_user.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );
        jsObjRequest.setTag(USERTAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                String id=jsonChildNode.getString("id");
                String distance=jsonChildNode.getString("distance");

                if (id.equals(MainActivity.user_id)) {
                    MainActivity.distance = distance;
                    MainActivity.USER_POSITION = i;
                }

                mArray.add(new UserInfo(id, distance));
            }
        } catch(JSONException | NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error"+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }
    }

    public class UserInfo {
        String id;
        String distance;

        public UserInfo(String id, String distance) {
            this.id = id; this.distance = distance;
        }

        public String getId() { return id; }

        public String getDistance() { return distance; }
    }

    public void onCourse(View v){
        Intent intent = new Intent(getApplicationContext(), ShowActivity.class);
        startActivity(intent);
    }

    public void onLodge(View v){
        Intent intent =  new Intent(getApplicationContext(), LodgeActivity.class);
        startActivity(intent);
    }

    public void onRecord(View v){
        Intent intent =  new Intent(getApplicationContext(), RecordActivity.class);
        startActivity(intent);
    }

    public void onQuestion(View v){
        Intent intent =  new Intent(getApplicationContext(),QuestionActivity.class);
        startActivity(intent);
    }
}

