package com.kit.fpb.bike;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.bumptech.glide.Glide;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;

public class LongWeatherActivity extends AppCompatActivity {
    protected String lRegion = "", cityName = "";

    protected JSONObject mResult = null;

    protected ArrayList<LongWeather> mArray = new ArrayList<LongWeather>();
    protected ListView mList;
    protected LongWeatherActivity.WeatherAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;
    protected Uri weather_uri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_long_weather);

        Intent intent = getIntent();
        lRegion = intent.getExtras().getString("lRegion");

        switch (lRegion) {
            case "105.0":
                lRegion = "105";
                cityName = "춘천";
                break;
            case "109.0":
                lRegion = "109";
                cityName = "서울";
                break;
            case "131.0":
                lRegion = "131";
                cityName = "청주";
                break;
            case "133.0":
                lRegion = "133";
                cityName = "대전";
                break;
            case "143.0":
                lRegion = "143";
                cityName = "대구";
                break;
            case "146.0":
                lRegion = "146";
                cityName = "전주";
                break;
            case "156.0":
                lRegion = "156";
                cityName = "광주";
                break;
            case "159.0":
                lRegion = "159";
                cityName = "부산";
                break;
        }

        new ReceiveLongWeather().execute();

        mAdapter = new WeatherAdapter(this, R.layout.course_long_weather);
        mList = (ListView) findViewById(R.id.longWeatherView);
        mList.setAdapter(mAdapter);
    }

    public class LongWeather {
        private String tmEf;
        private String wf;
        private String tmn;
        private String tmx;
        private Uri uri;

        public LongWeather(String tmEf, String wf, String tmn, String tmx, Uri uri) {
            this.tmEf = tmEf;
            this.wf = wf;
            this.tmn = tmn;
            this.tmx = tmx;
            this.uri = uri;
        }

        public LongWeather() { }

        public String getTmEf() { return tmEf; }

        public void setTmEf(String tmEf) { this.tmEf = tmEf; }

        public String getWf() { return wf; }

        public void setWf(String wf) { this.wf = wf; }

        public String getTmn() { return tmn; }

        public void setTmn(String tmn) { this.tmn = tmn; }

        public String getTmx() { return tmx; }

        public void setTmx(String tmx) { this.tmx = tmx; }

        public Uri getUri() { return uri; }
    }

    public class ReceiveLongWeather extends AsyncTask<URL, Integer, Long> {

        ArrayList<LongWeather> longWeathers = new ArrayList<LongWeather>();

        protected Long doInBackground(URL... urls) {
            String url = "http://www.kma.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=" + lRegion;

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            Response response = null;

            try {
                response = client.newCall(request).execute();
                parseWeekXML(response.body().string());
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onPostExecute(Long result) {
            String data = "";

            for(int i=0; i<longWeathers.size(); i++) {
                switch ( longWeathers.get(i).getWf()) {
                    case "맑음":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.clear);
                        break;
                    case "구름조금":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.cloud_less);
                        break;
                    case "구름많음":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.cloud);
                        break;
                    case "구름많고 비":
                    case "구름많고 비/눈":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.rain);
                        break;
                    case "구름많고 눈/비":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.snow);
                        break;
                    case "구름많고 눈":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.snow);
                        break;
                    case "흐림":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.cloud_less);
                        break;
                    case "흐리고 비":
                    case "흐리고 비/눈":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.rain);
                        break;
                    case "흐리고 눈/비":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.snow);
                        break;
                    case "흐리고 눈":
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.snow);
                        break;
                }
                mArray.add(new LongWeather(longWeathers.get(i).getTmEf(), longWeathers.get(i).getWf(), longWeathers.get(i).getTmn(), longWeathers.get(i).getTmx(), weather_uri));
            }

            mAdapter.notifyDataSetChanged();
        }

        void parseWeekXML(String xml) {
            try {
                String tagName = "";
                boolean onCity = false;
                boolean onTmEf = false;
                boolean onWf = false;
                boolean onTmn = false;
                boolean onTmx = false;
                boolean onEnd = false;
                boolean isItemTag1 = false;
                int i = 0;

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                XmlPullParser parser = factory.newPullParser();

                parser.setInput(new StringReader(xml));

                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        tagName = parser.getName();

                        if (tagName.equals("city")) {
                            eventType = parser.next();

                            if (parser.getText().equals(cityName)) {    // 파싱하고 싶은 지역 이름을 쓴다
                                onCity = true;
                            } else {
                                if (onCity) { // 이미 parsing을 끝냈을 경우
                                    break;
                                } else {        // 아직 parsing을 못했을 경우
                                    onCity = false;
                                }
                            }
                        }

                        if (tagName.equals("data") && onCity) {
                            longWeathers.add(new LongWeather());
                            onEnd = false;
                            isItemTag1 = true;
                        }
                    } else if (eventType == XmlPullParser.TEXT && isItemTag1 && onCity) {
                        if (tagName.equals("tmEf") && !onTmEf) {
                            longWeathers.get(i).setTmEf(parser.getText());
                            onTmEf = true;
                        }
                        if (tagName.equals("wf") && !onWf) {
                            longWeathers.get(i).setWf(parser.getText());
                            onWf = true;
                        }
                        if (tagName.equals("tmn") && !onTmn) {
                            longWeathers.get(i).setTmn(parser.getText());
                            onTmn = true;
                        }
                        if (tagName.equals("tmx") && !onTmx) {
                            longWeathers.get(i).setTmx(parser.getText());
                            onTmx = true;
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        if (tagName.equals("reliability") && onEnd == false) {
                            i++;
                            onTmEf = false;
                            onWf = false;
                            onTmn = false;
                            onTmx = false;
                            isItemTag1 = false;
                            onEnd = true;
                        }
                    }

                    eventType = parser.next();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static class WeatherViewHolder {
        ImageView imImage;
        TextView txDate;
        TextView txTemp;
        TextView txWfKor;
    }

    public class WeatherAdapter extends ArrayAdapter<LongWeather> {
        private LayoutInflater mInflater = null;

        public WeatherAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            WeatherViewHolder viewHolder;
            if (v == null) {
                v = mInflater.inflate(R.layout.course_long_weather, parent, false);
                viewHolder = new WeatherViewHolder();
                viewHolder.imImage = (ImageView) v.findViewById(R.id.imageWeather);
                viewHolder.txDate = (TextView) v.findViewById(R.id.long_date);
                viewHolder.txTemp = (TextView) v.findViewById(R.id.long_temp);
                viewHolder.txWfKor = (TextView) v.findViewById(R.id.long_wfkor);

                v.setTag(viewHolder);
                // viewHolder.imImage.setImageResource(0);
            } else {
                viewHolder = (WeatherViewHolder) v.getTag();
            }

            LongWeather info = mArray.get(position);
            if (info != null) {
                Glide.with(LongWeatherActivity.this).load(info.getUri()).into(viewHolder.imImage);
                viewHolder.txDate.setText(info.getTmEf());
                viewHolder.txTemp.setText("최저 : " + info.getTmn() + " ℃ / 최고 : " + info.getTmx() + " ℃");
                viewHolder.txWfKor.setText("날씨상태 : " + info.getWf());
            }

            return v;
        }
    }
}