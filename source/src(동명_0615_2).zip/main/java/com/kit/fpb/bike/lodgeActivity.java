package com.kit.fpb.bike;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Dolm on 2016-06-14.
 */
public class lodgeActivity extends Activity {
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.lodge_home);
    }
}
