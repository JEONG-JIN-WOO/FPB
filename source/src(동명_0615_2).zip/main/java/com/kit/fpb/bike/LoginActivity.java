package com.kit.fpb.bike;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Dolm on 2016-06-14.
 */
public class LoginActivity extends Activity{

    private EditText editTextID;
    private EditText editTextpassword;
    String id;
    String password;
    String LOGIN_URL = "http://128.199.238.222/login.php";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_home);

        startActivity(new Intent(this, SplashActivity.class));


        editTextID = (EditText) findViewById(R.id.inputID);
        editTextpassword = (EditText) findViewById(R.id.inputPW);
    }

    public void joinclick(View view)
    {
        Intent intent =  new Intent(LoginActivity.this,JoinActivity.class);
        startActivity(intent);
    }

    public void login(View v){
        id = editTextID.getText().toString().trim();
        password = editTextpassword.getText().toString().trim();

        //Creating a string request
        StringRequest StringRequest = new StringRequest(Request.Method.POST, LOGIN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //If we are getting success from server
                        if(response.trim().equals("success")){
                            Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT).show();
                            openProfile();
                        }else{
                            Toast.makeText(LoginActivity.this,"아이디 또는 비밀번호가 틀렸습니다." +
                                    "다시 입력해주세요.",Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginActivity.this,"Error",Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                //Adding parameters to request
                params.put("id", id);
                params.put("password", password);
                return params;
            }
        };
        //Adding the string request to the queue

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest.setShouldCache(false);
        requestQueue.add(StringRequest);
    }
    public void openProfile(){
        Intent intent = new Intent(this, MainmenuActivity.class);
        finish();
        startActivity(intent);
    }

}