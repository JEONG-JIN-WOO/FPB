package com.kit.fpb.bike;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ShowActivity extends AppCompatActivity {
    public static final String COURSETAG = "CourseTag";

    protected TextView mText;
    private LocationManager lm;
    private LocationListener ll;
    double mySpeed, maxSpeed;

    protected JSONObject mResult = null;
    protected ArrayList<CourseInfo> mArray = new ArrayList<CourseInfo>();
    protected ListView mList;
    protected CourseAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;
    protected int select = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        mText = (TextView) findViewById(R.id.speed);
        maxSpeed = mySpeed = 0;
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        ll = new SpeedoActionListener();
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, ll);
        } catch (SecurityException e) { Toast.makeText(ShowActivity.this, "SecurityException : Error", Toast.LENGTH_SHORT).show(); }

        mAdapter = new CourseAdapter(this, R.layout.course_item);
        mList = (ListView) findViewById(R.id.listView);
        mList.setAdapter(mAdapter);
        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CourseInfo info = mArray.get(position);

                final String sRegion = info.getsRegion();
                final String lRegion = info.getlRegion();
                final String items[] = { "단기예보", "중기예보", "삭제" };

                AlertDialog.Builder ab = new AlertDialog.Builder(ShowActivity.this);
                ab.setTitle("Weather Rider");
                ab.setSingleChoiceItems(items, 0,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                switch (whichButton) {
                                    case 0:
                                        select = 0;
                                        break;
                                    case 1:
                                        select = 1;
                                        break;
                                    case 2:
                                        select = 2;
                                        break;
                                }
                            }
                        }).setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                switch (select) {
                                    case -1:
                                    case 0:
                                        Intent intent_0 = new Intent(getApplicationContext(), ShortWeatherActivity.class);
                                        intent_0.putExtra("sRegion", sRegion);
                                        startActivity(intent_0);
                                        break;
                                    case 1:
                                        Intent intent_1 = new Intent(getApplicationContext(), LongWeatherActivity.class);
                                        intent_1.putExtra("lRegion", lRegion);
                                        startActivity(intent_1);
                                        break;
                                    case 2:
                                        Toast.makeText(ShowActivity.this, "당신의 선택은 ! : " + select, Toast.LENGTH_SHORT).show();
                                        break;
                                }
                            }
                        }).setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) { }
                        });
                ab.setIcon(R.drawable.app);
                ab.show();
            }
        });

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_show, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_map) {
            Intent intent = new Intent(getApplicationContext(), MapActivity.class);
            startActivity(intent);

            return true;
        } else if (id == R.id.action_start) {
            Toast.makeText(ShowActivity.this, "Start Button", Toast.LENGTH_LONG).show();

            return true;
        } else if (id == R.id.action_pause) {
            Toast.makeText(ShowActivity.this, "Pause Button", Toast.LENGTH_LONG).show();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class SpeedoActionListener implements LocationListener {
        @Override
        public void onLocationChanged(Location location) {
            if (location != null) {
                mySpeed = location.getSpeed();
                if (mySpeed > maxSpeed) {
                    maxSpeed = mySpeed;
                }
                mText.setText("Current Speed : " + mySpeed + " km/h, Max Speed : " + maxSpeed + " km/h");
            }
        }

        @Override
        public void onProviderDisabled(String provider) { }

        @Override
        public void onProviderEnabled(String provider) { }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) { }
    }

    protected void requestCourse()
    {
        String url ="http://128.199.238.222/selectjson.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ShowActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );
        jsObjRequest.setTag(COURSETAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                String name=jsonChildNode.getString("name");
                String sRegion=jsonChildNode.getString("sRegion");
                String lRegion=jsonChildNode.getString("lRegion");

                mArray.add(new CourseInfo(name, sRegion, lRegion));
            }
        }catch(JSONException |NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error"+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }
        mAdapter.notifyDataSetChanged();
    }

    public class CourseInfo {
        String name;
        String sRegion;
        String lRegion;

        public CourseInfo() { }

        public CourseInfo(String name, String sRegion, String lRegion) {
            this.name = name;
            this.sRegion = sRegion;
            this.lRegion = lRegion;
        }

        public String getName() { return name; }

        public String getsRegion() { return sRegion; }

        public String getlRegion() { return lRegion; }
    }

    static class CourseViewHolder {
        TextView txName;
        TextView txDistance;
        TextView txToDistance;
    }

    public class CourseAdapter extends ArrayAdapter<CourseInfo> {
        private LayoutInflater mInflater = null;
        public CourseAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.course_item, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txName = (TextView) v.findViewById(R.id.name);
                viewHolder.txDistance = (TextView) v.findViewById(R.id.distance);
                viewHolder.txToDistance = (TextView) v.findViewById(R.id.todistance);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            CourseInfo info = mArray.get(position);
            if(info != null) {
                viewHolder.txName.setText(info.getName());
                //viewHolder.txDistance.setText(info.getTemp());
                //viewHolder.txToDistance.setText(info.getRain());
            }
            return  v;
        }
    }
}