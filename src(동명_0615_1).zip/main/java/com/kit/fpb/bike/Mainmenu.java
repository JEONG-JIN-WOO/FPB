package com.kit.fpb.bike;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by Dolm on 2016-06-07.
 */

public class Mainmenu extends AppCompatActivity {

    public static String User_ID ="";
    Intent intent = getIntent();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu_home);

//        User_ID = intent.getExtras().getString("User_ID");

    }

  public void Roadclick(View v){
      Intent intent = new Intent(getApplicationContext(),MainActivity.class);
      startActivity(intent);

  }
    public void questionclick(View v){
        Intent intent =  new Intent(getApplicationContext(),Question.class);
        startActivity(intent);
    }

    public void onLodge(View v){
        Intent intent =  new Intent(getApplicationContext(), LodgeActivity.class);
        startActivity(intent);
    }


}

