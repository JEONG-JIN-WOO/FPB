package com.kit.fpb.bike;

/**
 * Created by Dolm on 2016-06-14.
 */
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by Dolm on 2016-06-07.
 */

public class Question extends AppCompatActivity {

    protected JSONObject mResult = null;
    protected ListView listview;
    protected ArrayList<TravelInfo> arrayList;
    protected ArrayAdapter adapter;
    protected RequestQueue mQueue = null;

    String url = "http://128.199.238.222/read.php";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);



        arrayList = new ArrayList<TravelInfo>();
        adapter = new TravelAdapter(this,R.layout.list_item);

        listview = (ListView) findViewById(R.id.list);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                                                TravelInfo info = arrayList.get(position);
                                                Intent intent = new Intent(Question.this,Question_Show.class);
                                                intent.putExtra("title",info.gettitle());
                                                intent.putExtra("description",info.getDescription());
                                                startActivity(intent);

                                            }
                                        }
        );

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        getData();
    }

    protected void getData() {
        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>() {
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Question.this, "서버 에러", Toast.LENGTH_LONG).show();

                    }
                }
        );
        mQueue.add(jsObjRequest);
    }

    public void writeclick(View v) {
        Intent intent = new Intent(getApplicationContext(), Question_write.class);
        startActivity(intent);
    }

    public void drawList() {

        try {
            JSONArray jsonMainNode = mResult.getJSONArray("list");

            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                String title = jsonChildNode.getString("title");
                String description = jsonChildNode.getString("description");
                arrayList.add(new TravelInfo(title,description));
            }
        } catch (JSONException | NullPointerException e) {
            Toast.makeText(getApplicationContext(), "Error" + e.toString(), Toast.LENGTH_LONG).show();
            mResult = null;
        }
        adapter.notifyDataSetChanged();
    }

    public class TravelInfo {
        String title;
        String description;

        public TravelInfo(String title,String description) {
            this.title = title;
            this.description = description;
        }

        public String title() {
            return title;
        }
        public String Description() { return description;}
        public String gettitle(){
            return title;
        }
        public String getDescription() { return description;}

    }

    static class TravelViewHolder {

        TextView txtitle;

    }

    public class TravelAdapter extends ArrayAdapter<TravelInfo> {
        private LayoutInflater mInflater = null;

        public TravelAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            TravelViewHolder viewHolder;
            if (v == null) {
                v = mInflater.inflate(R.layout.list_item, parent, false);
                viewHolder = new TravelViewHolder();
                viewHolder.txtitle = (TextView) v.findViewById(R.id.text1);
                v.setTag(viewHolder);
            } else {
                viewHolder = (TravelViewHolder) v.getTag();
            }

            TravelInfo info = arrayList.get(position);
            if (info != null) {

                viewHolder.txtitle.setText(info.gettitle());

            }
            return v;

        }
    }
}