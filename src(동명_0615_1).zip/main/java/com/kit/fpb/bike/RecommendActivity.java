package com.kit.fpb.bike;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RecommendActivity extends AppCompatActivity {
    public static final String COURSETAG = "CourseTag";

    protected JSONObject mResult = null;

    protected ArrayList<CourseInfo> mArray = new ArrayList<CourseInfo>();
    protected ListView mList;
    protected CourseAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;

    public static final String KEY_ID = "user_id";
    public static final String KEY_COURSE = "course";
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_LAT = "lat";
    public static final String KEY_LNG = "lng";
    public static final String KEY_SREGION = "sRegion";
    public static final String KEY_LREGION = "lRegion";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend);

        mAdapter = new CourseAdapter(this, R.layout.course_recommend);
        mList = (ListView) findViewById(R.id.recommendView);
        mList.setAdapter(mAdapter);
        mList.setFocusable(false);

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();

        requestCourse();
    }

    protected void requestCourse()
    {
        String url ="http://128.199.238.222/course_recommend.php";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mResult = response;
                        drawList();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RecommendActivity.this, "DB 연동 에러", Toast.LENGTH_LONG).show();
                    }
                }
        );
        jsObjRequest.setTag(COURSETAG);
        mQueue.add(jsObjRequest);
    }

    public void drawList(){
        mArray.clear();
        try{
            JSONArray jsonMainNode=mResult.getJSONArray("list");

            for(int i=0;i<jsonMainNode.length();i++){
                JSONObject jsonChildNode=jsonMainNode.getJSONObject(i);

                String name=jsonChildNode.getString("name");
                String content=jsonChildNode.getString("content");
                String distance=jsonChildNode.getString("distance");
                String time=jsonChildNode.getString("time");
                mArray.add(new CourseInfo(name, content, distance, time));
            }
        }catch(JSONException | NullPointerException e){
            Toast.makeText(getApplicationContext(),"Error"+e.toString(),Toast.LENGTH_LONG).show();
            mResult=null;
        }
        mAdapter.notifyDataSetChanged();
    }

    public class CourseInfo {
        String name;
        String content;
        String distance;
        String time;

        public CourseInfo(String name, String content, String distance, String time) {
            this.name = name;
            this.content = content;
            this.distance = distance;
            this.time = time;
        }

        public String getName() { return name; }

        public String getContent() { return content; }

        public String getDistance() { return distance; }

        public String getTime() { return time; }
    }

    static class CourseViewHolder {
        TextView txName;
        TextView txContent;
        TextView txDistance;
    }

    public class CourseAdapter extends ArrayAdapter<CourseInfo> {
        private LayoutInflater mInflater = null;
        public CourseAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            CourseViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.course_setup, parent, false);
                viewHolder = new CourseViewHolder();
                viewHolder.txName = (TextView) v.findViewById(R.id.name);
                viewHolder.txContent = (TextView) v.findViewById(R.id.content);
                viewHolder.txDistance = (TextView) v.findViewById(R.id.distance);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (CourseViewHolder) v.getTag();
            }

            CourseInfo info = mArray.get(position);
            if(info != null) {
                viewHolder.txName.setText(info.getName());
                viewHolder.txContent.setText(info.getContent());
                //viewHolder.txDistance.setText("총 이동거리 : " + info.getDistance() + " / 예상 소요시간 : " + info.getTime());
            }
            return  v;
        }
    }
}