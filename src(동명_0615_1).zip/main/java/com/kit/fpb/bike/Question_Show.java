package com.kit.fpb.bike;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

/**
 * Created by Dolm on 2016-06-11.
 */
public class Question_Show extends ActionBarActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question_show_home);

        Bundle bundle = getIntent().getExtras();
        String text = bundle.getString("title");
        String text1 = bundle.getString("description");
        TextView title = (TextView)findViewById(R.id.question_text);
        title.setText(text);
        TextView content = (TextView)findViewById(R.id.question_content);
        content.setText(text1);
    }
}