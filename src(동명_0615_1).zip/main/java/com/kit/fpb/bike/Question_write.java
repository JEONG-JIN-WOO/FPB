package com.kit.fpb.bike;

/**
 * Created by Dolm on 2016-06-14.
 */
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Dolm on 2016-06-10.
 */
public class Question_write extends Activity {
    String url = "http://128.199.238.222/question.php";
    String title;
    String description;
    EditText editText_title;
    EditText editText_description;
    ProgressDialog PD;
    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.question_write_home);

        PD = new ProgressDialog(this);
        PD.setMessage("Loading.....");
        PD.setCancelable(false);

        editText_title= (EditText) findViewById(R.id.item_title);
        editText_description=(EditText)findViewById(R.id.item_description);



    }
    public void writeend(View v) {
        PD.show();
        title = editText_title.getText().toString();
        description= editText_description.getText().toString();

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    public void onResponse(String response) {
                        PD.dismiss();
                        editText_title.setText("");
                        editText_description.setText("");
                        Toast.makeText(getApplicationContext(),
                                "Data Inserted Successfully",
                                Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(Question_write.this,Question.class);
                        intent.putExtra("title_name",title);
                        intent.putExtra("description_name",description);
                        startActivity(intent);



                    }
                }, new Response.ErrorListener() {

            public void onErrorResponse(VolleyError error) {
                PD.dismiss();
                Toast.makeText(getApplicationContext(),
                        "failed to insert", Toast.LENGTH_SHORT).show();
            }
        }) {

            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("item_title", title);
                params.put("item_description",description);
                return params;
            }
        };
        // Adding request to request queue
        MyApplication.getInstance().addToReqQueue(request);
    }
}