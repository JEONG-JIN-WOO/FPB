package com.kit.fpb.bike;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.bumptech.glide.Glide;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;

public class ShortWeatherActivity extends AppCompatActivity {

    //TextView textView_shortWeather;
    String sRegion = "";

    public static final String TRAVELTAG = "TravelTag";

    protected JSONObject mResult = null;

    protected ArrayList<ShortWeather> mArray = new ArrayList<ShortWeather>();
    protected ListView mList;
    protected WeatherAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected ImageLoader mImageLoader = null;
    protected Uri weather_uri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_short_weather);

        Intent intent = getIntent();
        sRegion = intent.getExtras().getString("sRegion");

        new ReceiveShortWeather().execute();

        mAdapter = new WeatherAdapter(this, R.layout.course_short_weather);
        mList = (ListView) findViewById(R.id.shortWeatherView);
        mList.setAdapter(mAdapter);
    }

    public class ShortWeather {
        private String hour;  // 시간
        private String day;
        private String temp;  // 온도
        private String wfKor; // 상태
        private String pop; // 강수확률
        private String reh; // 습도
        private String tmx;
        private String tmn;
        private Uri uri;

        public ShortWeather(String hour, String day, String temp, String wfKor, String pop, String tmx, String tmn, Uri uri) {
            this.hour = hour;
            this.day = day;
            this.temp = temp;
            this.wfKor = wfKor;
            this.pop = pop;
            this.tmx = tmx;
            this.tmn = tmn;
            this.uri = uri;
        }

        public ShortWeather() { }

        public String getTmx() { return tmx; }

        public void setTmx(String tmx) { this.tmx = tmx; }

        public String getTmn() { return tmn; }

        public void setTmn(String tmn) { this.tmn = tmn; }

        public String getDay() { return day; }

        public void setDay(String day) { this.day = day; }

        public String getReh() { return reh; }

        public void setReh(String reh) { this.reh = reh;}

        public String getPop() { return pop; }

        public void setPop(String pop) { this.pop = pop; }

        public void setHour(String hour) { this.hour = hour; }

        public void setTemp(String temp) { this.temp = temp; }

        public void setWfKor(String wfKor) { this.wfKor = wfKor; }

        public String getHour() { return hour; }

        public String getTemp() { return temp; }

        public String getWfKor() { return wfKor; }

        public Uri getUri() { return uri; }
    }

    public class ReceiveShortWeather extends AsyncTask<URL, Integer, Long> {

        ArrayList<ShortWeather> shortWeathers = new ArrayList<ShortWeather>();

        protected Long doInBackground(URL... urls) {

            String url = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=" + sRegion;

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            Response response = null;

            try {
                response = client.newCall(request).execute();
                parseXML(response.body().string());
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onPostExecute(Long result) {

            for(int i=0; i<shortWeathers.size(); i++) {
                switch (shortWeathers.get(i).getWfKor()) {
                    case "맑음":
                        Log.d("test-0614", "맑음");
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.clear);
                        break;
                    case "구름 조금":
                        Log.d("test-0614", "구름 조금");
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.cloud_less);
                        break;
                    case "구름 많음":
                        Log.d("test-0614", "구름 많음");
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.cloud);
                        break;
                    case "흐림":
                        Log.d("test-0614", "흐림");
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.cloud_less);
                        break;
                    case "비":
                        Log.d("test-0614", "비");
                        weather_uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.drawable.rain);
                        break;
                }
                mArray.add(new ShortWeather(shortWeathers.get(i).getHour(), shortWeathers.get(i).getDay(), shortWeathers.get(i).getTemp(), shortWeathers.get(i).getWfKor(),
                                                shortWeathers.get(i).getPop(), shortWeathers.get(i).getTmx(), shortWeathers.get(i).getTmn(), weather_uri));
            }

            mAdapter.notifyDataSetChanged();
            //textView_shortWeather.setText(data);
        }

        void parseXML(String xml) {
            try {
                String tagName = "";
                boolean onHour = false;
                boolean onDay = false;
                boolean onTem = false;
                boolean onWfKor = false;
                boolean onTmn = false;
                boolean onTmx = false;
                boolean onPop = false;
                boolean onEnd = false;
                boolean isItemTag1 = false;
                int i = 0;

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                XmlPullParser parser = factory.newPullParser();

                parser.setInput(new StringReader(xml));

                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        tagName = parser.getName();
                        if (tagName.equals("data")) {
                            shortWeathers.add(new ShortWeather());
                            onEnd = false;
                            isItemTag1 = true;
                        }
                    } else if (eventType == XmlPullParser.TEXT && isItemTag1) {
                        if (tagName.equals("hour") && !onHour) {
                            shortWeathers.get(i).setHour(parser.getText());
                            onHour = true;
                        }
                        if (tagName.equals("day") && !onDay) {
                            shortWeathers.get(i).setDay(parser.getText());
                            onDay = true;
                        }
                        if (tagName.equals("temp") && !onTem) {
                            shortWeathers.get(i).setTemp(parser.getText());
                            onTem = true;
                        }
                        if (tagName.equals("wfKor") && !onWfKor) {
                            shortWeathers.get(i).setWfKor(parser.getText());
                            onWfKor = true;
                        }
                        if (tagName.equals("tmx") && !onTmx) {
                            shortWeathers.get(i).setTmx(parser.getText());
                            onTmx = true;
                        }
                        if (tagName.equals("tmn") && !onTmn) {
                            shortWeathers.get(i).setTmn(parser.getText());
                            Log.d("qwerts", shortWeathers.get(i).getTmn());
                            onTmn = true;
                        }
                        if (tagName.equals("pop") && !onPop) {
                            shortWeathers.get(i).setPop(parser.getText());
                            onPop = true;
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        if (tagName.equals("s06") && onEnd == false) {
                            i++;
                            onHour = false;
                            onDay = false;
                            onTem = false;
                            onWfKor = false;
                            onTmx = false;
                            onTmn = false;
                            onPop = false;
                            isItemTag1 = false;
                            onEnd = true;
                        }
                    }

                    eventType = parser.next();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static class WeatherViewHolder {
        ImageView imImage;
        TextView txDate;
        TextView txTmn;
        TextView txTmx;
        TextView txPop;
        TextView txWfKor;
    }

    public class WeatherAdapter extends ArrayAdapter<ShortWeather> {
        private LayoutInflater mInflater = null;
        public WeatherAdapter(Context context, int resource) {
            super(context, resource);
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return mArray.size();
        }

        @Override
        public View getView(int position, View v, ViewGroup parent) {
            WeatherViewHolder viewHolder;
            if(v == null) {
                v = mInflater.inflate(R.layout.course_short_weather, parent, false);
                viewHolder = new WeatherViewHolder();
                viewHolder.imImage = (ImageView) v.findViewById(R.id.imageWeather);
                viewHolder.txDate = (TextView) v.findViewById(R.id.short_date);
                viewHolder.txTmn = (TextView) v.findViewById(R.id.short_tmn);
                viewHolder.txTmx = (TextView) v.findViewById(R.id.short_tmx);
                viewHolder.txPop = (TextView) v.findViewById(R.id.short_pop);
                viewHolder.txWfKor = (TextView) v.findViewById(R.id.short_wfkor);

                v.setTag(viewHolder);
            }
            else {
                viewHolder = (WeatherViewHolder) v.getTag();
            }

            ShortWeather info = mArray.get(position);
            if(info != null) {
                String date = null;
                Calendar cal = Calendar.getInstance();

                switch (info.getDay()) {
                    case "0":
                       date = cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH)+1) + "-" + cal.get(Calendar.DAY_OF_MONTH);
                        break;
                    case "1":
                        date = cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH)+1) + "-" + (cal.get(Calendar.DAY_OF_MONTH)+1);
                        break;
                    case "2":
                        date = cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH)+1) + "-" + (cal.get(Calendar.DAY_OF_MONTH)+2);
                        break;
                }

                switch (info.getHour()) {
                    case "3":
                    case "6":
                    case "9":
                        date = date + " 0" + info.getHour() + ":00";
                        break;
                    default:
                        date = date + " " + info.getHour() + ":00";
                        break;
                }

                Glide.with(ShortWeatherActivity.this).load(info.getUri()).into(viewHolder.imImage);
                viewHolder.txDate.setText(date);
                viewHolder.txTmn.setText("최저온도 : " + info.getTmn() + " ℃");
                viewHolder.txTmx.setText("최고온도 : " + info.getTmx() + " ℃");
                viewHolder.txPop.setText("강수확률 : " + info.getPop() + " %");
                viewHolder.txWfKor.setText("날씨상태 : " + info.wfKor);
            }

            return  v;
        }
    }
}